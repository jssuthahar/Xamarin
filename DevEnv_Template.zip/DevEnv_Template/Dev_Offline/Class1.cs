﻿using System;

namespace Dev_Offline
{
    public class Class1
    {
    }
}
