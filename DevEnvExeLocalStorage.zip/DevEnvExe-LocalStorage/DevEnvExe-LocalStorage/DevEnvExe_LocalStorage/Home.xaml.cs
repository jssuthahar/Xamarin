﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace DevEnvExe_LocalStorage
{
    public partial class Home : ContentPage
    {
        public Home(string userid)
        {
            InitializeComponent();
            Readtext(userid);
           
            
        }

        public async void Readtext(string userid)
        {
            string textcontent = await PCLHelper.ReadAllTextAsync(userid);
            string[] value = textcontent.Split('\n');
            txtname.Text = value[0].ToString();
            txtuserid.Text = value[1].ToString();
            txtpassword.Text = value[2].ToString();
        }
        async void Click_UpdateProfile(object sender, EventArgs e)
        {
            bool result = false;

            bool fileexist = await txtuserid.Text.IsFileExistAsync();
            if (fileexist == true)
            {
                if (txtname.Text != "" && txtpassword.Text != "" && txtuserid.Text != "")
                    result = await txtuserid.Text.WriteTextAllAsync(ContentBuilder(txtname.Text, txtuserid.Text, txtpassword.Text));

                if (result != true)
                {
                    await DisplayAlert("Update Profile", "Update Fail .. Please try again ", "OK");
                }
                else
                {
                    await DisplayAlert("Update Profile", "Profile update Success . ", "OK");
                   
                }
            }
            else
            {
                await DisplayAlert("Update Profile", "try again . ", "OK");
            }
          
        }
        public string ContentBuilder(params string[] content)
        {
            StringBuilder contentbuilder = new StringBuilder();
            foreach (var item in content)
            {
                contentbuilder.AppendLine(item.ToString());
            }
            return contentbuilder.ToString();
        }
        async void Click_Login(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new MainPage());
        }
    }
}
