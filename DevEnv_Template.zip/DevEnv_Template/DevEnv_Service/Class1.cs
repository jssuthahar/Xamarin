﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DevEnv_Service
{
    public class Class1
    {
    }
}
