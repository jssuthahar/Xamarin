﻿using System;
using Xamarin.Forms;
using PCLStorage;

namespace DevEnvExe_LocalStorage
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
        async void Click_Reg(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new Registration());
        }

        async void Click_Login(object sender, EventArgs e)
        {
            bool isexist = await PCLHelper.IsFileExistAsync(txtuserid.Text);

            if (isexist != true)
            {
                await DisplayAlert("Login", "Login failed .. Please try again ", "OK");
            }
            else
            {
                await DisplayAlert("Registrtion", "Login Success ... Now Edit your profile ", "OK");
                await Navigation.PushModalAsync(new Home(txtuserid.Text));
            }
            
           
        }
        
    }
}
