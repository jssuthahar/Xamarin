﻿using System;
using Xamarin.Forms;

namespace ReadOTPIOS
{
    public class AutoFillControl : Entry
    {
        public AutoFillControl()
        {
        }
    }
}
