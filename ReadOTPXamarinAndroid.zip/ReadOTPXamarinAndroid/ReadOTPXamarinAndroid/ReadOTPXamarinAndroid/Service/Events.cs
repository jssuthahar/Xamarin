﻿using System;
namespace ReadOTPXamarinAndroid
{
    public enum Events
    {
        SmsRecieved,
    }
}
