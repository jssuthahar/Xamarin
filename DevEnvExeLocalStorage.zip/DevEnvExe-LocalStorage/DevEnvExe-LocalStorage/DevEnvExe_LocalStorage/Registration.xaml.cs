﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PCLStorage;

using Xamarin.Forms;

namespace DevEnvExe_LocalStorage
{
    public partial class Registration : ContentPage
    {
        public Registration()
        {
            InitializeComponent();
        }
        async void Click_Reg(object sender, EventArgs e)
        {
            bool result = false;

            bool fileexist = await txtuserid.Text.IsFileExistAsync();
            if (fileexist != true)
            {
                if (txtname.Text != "" && txtpassword.Text != "" && txtuserid.Text != "")
                    result = await txtuserid.Text.WriteTextAllAsync(ContentBuilder(txtname.Text, txtuserid.Text, txtpassword.Text));

                if (result != true)
                {
                    await DisplayAlert("Registrtion", "Registrtion Fail .. Please try again ", "OK");
                }
                else
                {
                    await DisplayAlert("Registrtion", "Registrtion Success ... Login and Edit profile ", "OK");
                    await Navigation.PushModalAsync(new MainPage());
                }
            }
            else
            {
                await DisplayAlert("Registrtion Failed", "username already exist .. Please try differnt user name ", "OK");
                txtuserid.Text = "";
                txtuserid.Focus();
                
            }

        }
        async void Click_Login(object sender, EventArgs e)
        {
            await Navigation.PushModalAsync(new MainPage());
        }

        public string ContentBuilder(params string[] content)
        {
            StringBuilder contentbuilder = new StringBuilder();
            foreach (var item in content)
            {
                contentbuilder.AppendLine(item.ToString());
            }
            return contentbuilder.ToString();
        }
    }
}
